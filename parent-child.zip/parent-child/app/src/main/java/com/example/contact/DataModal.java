package com.example.contact;

public class DataModal {



    // string variables for our name and job
    private String name;
    private String job;

    public DataModal(String name, String job) {
        this.name = name;
        this.job = job;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

}

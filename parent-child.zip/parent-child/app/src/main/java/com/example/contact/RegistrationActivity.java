package com.example.contact;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//import com.google.android.gms.dtdi.analytics.Results;


public class RegistrationActivity extends AppCompatActivity {

    private Button btnGetData;
    private ListView listView;
    private Button notify;
    private Button limit,restrict;
    MyDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);
        btnGetData = findViewById(R.id.btnGetData);
        listView = findViewById(R.id.listviewData);
        notify = findViewById(R.id.notify);
        limit = findViewById(R.id.limit);
        restrict = findViewById(R.id.restrict);

        dbHandler= new MyDBHandler(this);
        OkHttpClient client = new OkHttpClient();
        String url = "https://hamfarmug.com/mobile/view2.php";


        btnGetData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


   // reead data
                String parent = dbHandler.loadHandler();


                RequestBody formBody = new FormBody.Builder()
                        .add("parent", parent)
                        .add("code", "56")
                        .build();

                Request request = new Request.Builder()
                        .url(url)
                        .post(formBody)
                        .build();


                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        e.printStackTrace();
                    }
                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {


                        if (response.isSuccessful()) {
                            //final String myResponse = response.body().string();
                            // final String comp ="yes";
                            RegistrationActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    // Toast.makeText(getApplicationContext(), "invalid word", Toast.LENGTH_LONG).show();

                                    Api methods = RetrofitClient.getRetrofitInstance().create(Api.class);
                                    Call < Model > call = methods.getAllData();
                                    call.enqueue(new Callback < Model > () {
                                        @Override
                                        public void onResponse(Call < Model > call, Response < Model > response) {
                                            ArrayList < Model.data > data = response.body().getData();
                                            String[] names = new String[data.size()];
                                            for (int i = 0; i < data.size(); i++) {
                                                names[i] =  data.get(i).getSearch();
                                                //names[i] =  data.get(i).getCode();
                                            }
                                            listView.setAdapter(new ArrayAdapter < String > (getApplicationContext(), android.R.layout.simple_list_item_1, names));
                                        }
                                        @Override
                                        public void onFailure(Call < Model > call, Throwable t) {
                                            Toast.makeText(getApplicationContext(), "An error has occured", Toast.LENGTH_LONG).show();
                                        }
                                    });




                                }
                            });
                        }


                    }
                });

        //......



            }
        });

        // link to notification page


        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                // term = editText.getText().toString();
                //intent.putExtra(SearchManager.QUERY, term);
                //startActivity(intent);


                //Toast.makeText(getApplicationContext(), "Redirecting...",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegistrationActivity.this, NotifyActivity.class);
                startActivity(intent);



            }
        });


        limit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                // term = editText.getText().toString();
                //intent.putExtra(SearchManager.QUERY, term);
                //startActivity(intent);


                //Toast.makeText(getApplicationContext(), "Redirecting...",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegistrationActivity.this, LimitActivity.class);
                startActivity(intent);



            }
        });

        //........


        restrict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                // term = editText.getText().toString();
                //intent.putExtra(SearchManager.QUERY, term);
                //startActivity(intent);


                //Toast.makeText(getApplicationContext(), "Redirecting...",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegistrationActivity.this, WordActivity.class);
                startActivity(intent);



            }
        });

        //.......



    }



}

package com.example.contact;

import java.util.ArrayList;

public class NotModel {


    public ArrayList<NotModel.data> data;


    public ArrayList < NotModel.data > getData() {
        return data;
    }
    public void setData(ArrayList < NotModel.data > data) {
        this.data = data;
    }
    public class data {

        public String notice;
        public String code;
        public String getCode() {
            return code;
        }

        public String getNotice() {
            return notice;
        }
        public void setNotice(String notice) {
            this.notice = notice;
        }

    }


}


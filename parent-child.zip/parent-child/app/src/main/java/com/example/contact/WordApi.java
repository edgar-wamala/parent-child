package com.example.contact;

import retrofit2.Call;
import retrofit2.http.GET;

public interface WordApi {

    @GET("mobile/word.php")
    Call<WordModel> getAllData();
}

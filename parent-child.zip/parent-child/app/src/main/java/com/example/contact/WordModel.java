package com.example.contact;

import java.util.ArrayList;

public class WordModel {

    public ArrayList<WordModel.data> data;


    public ArrayList <WordModel.data> getData() {
        return data;
    }
    public void setData(ArrayList <WordModel.data> data) {
        this.data = data;
    }
    public class data {

        public String word;
        public String code;
        public String getCode() {
            return code;
        }

        public String getWord() {
            return word;
        }
        public void setWord(String word) {
            this.word = word;
        }

    }
}

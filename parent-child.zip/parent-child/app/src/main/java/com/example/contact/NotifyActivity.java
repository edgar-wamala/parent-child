package com.example.contact;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotifyActivity extends AppCompatActivity {
    private ListView listView;
    MyDBHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notify);
        listView = findViewById(R.id.listviewData);

        dbHandler= new MyDBHandler(this);
        OkHttpClient client = new OkHttpClient();
        String url = "https://hamfarmug.com/mobile/notView2.php";


        //.......


        String parent = dbHandler.loadHandler();


        RequestBody formBody = new FormBody.Builder()
                .add("parent", parent)
                .add("code", "56")
                .build();

        Request request = new Request.Builder()
                .url(url)
                .post(formBody)
                .build();


        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {


                if (response.isSuccessful()) {
                    //final String myResponse = response.body().string();
                    // final String comp ="yes";
                    NotifyActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            // Toast.makeText(getApplicationContext(), "invalid word", Toast.LENGTH_LONG).show();

                            NotApi methods = RetrofitClient.getRetrofitInstance().create(NotApi.class);
                            Call< NotModel > call = methods.getAllData();
                            call.enqueue(new Callback< NotModel >() {
                                @Override
                                public void onResponse(Call < NotModel > call, Response< NotModel > response) {
                                    ArrayList< NotModel.data > data = response.body().getData();
                                    String[] names = new String[data.size()];
                                    for (int i = 0; i < data.size(); i++) {
                                        names[i] =  data.get(i).getNotice();
                                        //names[i] =  data.get(i).getCode();
                                    }
                                    listView.setAdapter(new ArrayAdapter< String >(getApplicationContext(), android.R.layout.simple_list_item_1, names));
                                }
                                @Override
                                public void onFailure(Call < NotModel > call, Throwable t) {
                                    Toast.makeText(getApplicationContext(), "An error has occured", Toast.LENGTH_LONG).show();
                                }
                            });




                        }
                    });
                }


            }
        });





        //...




    }



}

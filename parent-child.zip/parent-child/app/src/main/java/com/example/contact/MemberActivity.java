package com.example.contact;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MemberActivity extends AppCompatActivity {

    EditText password;
    EditText email;
    EditText name;
    Button btnReg;
    EditText code;
    EditText age;
    EditText child;
    MyDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member);

        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        name = findViewById(R.id.name);
        btnReg = findViewById(R.id.btnReg);
        code = findViewById(R.id.code);
        age = findViewById(R.id.age);


        dbHandler= new MyDBHandler(this);

        //mTextViewResult = findViewById(R.id.text_view_result);

        OkHttpClient client = new OkHttpClient();
        String url = "https://hamfarmug.com/mobile/register.php";



        btnReg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String password2 = password.getText().toString();
                String email2 = email.getText().toString();
                String name2 = name.getText().toString();
                String code2 = code.getText().toString();
                String age2 = age.getText().toString();

                RequestBody formBody = new FormBody.Builder()
                        .add("name", name2)
                        .add("password", password2)
                        .add("email", email2)
                        .add("code", code2)
                        .add("age", age2)

                        .build();

                Request request = new Request.Builder()
                        .url(url)
                        .post(formBody)
                        .build();


                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }
                    @Override
                    public void onResponse(Call call, Response response) throws IOException {


                        if (response.isSuccessful()) {
                            final String myResponse = response.body().string();

                            MemberActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    Toast.makeText(getApplicationContext(), "sucessfully registered", Toast.LENGTH_LONG).show();

                                    // sqlite
                                    int id = Integer.parseInt(code.getText().toString());
                                    String nameS = name.getText().toString();
                                    Student student = new Student(id, nameS);
                                    dbHandler.addHandler(student);



                                }
                            });
                        }


                    }
                });


            }
        });






    }

}

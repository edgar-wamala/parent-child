package com.example.contact;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WordActivity extends AppCompatActivity {
    private ListView listView;
    MyDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word);
        listView = findViewById(R.id.listviewData);

        dbHandler= new MyDBHandler(this);
        OkHttpClient client = new OkHttpClient();
        String url = "https://hamfarmug.com/mobile/word2.php";


// ........

        String parent = dbHandler.loadHandler();


        RequestBody formBody = new FormBody.Builder()
                .add("parent", parent)
                .add("code", "56")
                .build();

        Request request = new Request.Builder()
                .url(url)
                .post(formBody)
                .build();


        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {


                if (response.isSuccessful()) {
                    //final String myResponse = response.body().string();
                    // final String comp ="yes";
                    WordActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            // Toast.makeText(getApplicationContext(), "invalid word", Toast.LENGTH_LONG).show();

                            WordApi methods = RetrofitClient.getRetrofitInstance().create(WordApi.class);
                            Call<WordModel> call = methods.getAllData();
                            call.enqueue(new Callback<WordModel>() {
                                @Override
                                public void onResponse(Call<WordModel> call, Response<WordModel> response) {
                                    ArrayList<WordModel.data> data = response.body().getData();
                                    String[] names = new String[data.size()];
                                    for (int i = 0; i < data.size(); i++) {
                                        names[i] = data.get(i).getWord();
                                        //names[i] =  data.get(i).getCode();
                                    }
                                    listView.setAdapter(new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, names));
                                }

                                @Override
                                public void onFailure(Call<WordModel> call, Throwable t) {
                                    Toast.makeText(getApplicationContext(), "An error has occured", Toast.LENGTH_LONG).show();
                                }
                            });




                        }
                    });
                }


            }
        });








    }
    }


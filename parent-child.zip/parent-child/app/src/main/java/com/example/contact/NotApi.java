package com.example.contact;

import retrofit2.Call;
import retrofit2.http.GET;

public interface NotApi {

    @GET("mobile/notView.php")
    Call<NotModel> getAllData();

}

package com.example.contact;

import java.util.ArrayList;
public class Model {

    public ArrayList < data > data;


    public ArrayList < Model.data > getData() {
        return data;
    }
    public void setData(ArrayList < Model.data > data) {
        this.data = data;
    }
    public class data {

        public String search;
        public String code;
        public String getCode() {
            return code;
        }

        public String getSearch() {
            return search;
        }
        public void setSearch(String search) {
            this.search = search;
        }

    }
}


